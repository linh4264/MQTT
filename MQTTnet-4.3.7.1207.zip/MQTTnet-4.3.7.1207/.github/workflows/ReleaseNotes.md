* Core: Fixed issue when parsing AUTH packet with 0 length body (#2039).
* nuget: Changed code signing and nuget certificate (**BREAKING CHANGE**).
* TopicTemplates: Updated samples, parameter validation (#2022).
* ManagedClient: Switch SubscribeAsync/UnsubscribeAsync to IEnumerable<string> (#2026).
* Server: Fix _LoadingRetainedMessageAsync_ not executed (#2025).